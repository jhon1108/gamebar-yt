using Microsoft.Gaming.XboxGameBar;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Windows.System;
using Windows.UI.Core;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;

namespace YouTubeGameBar
{
    public sealed partial class MainPage : Page
    {
        // YouTube en modo TV (interfaz pensada para mando).
        private const string TvUrl = "https://www.youtube.com/tv";

        // User-Agent de consola/TV para que YouTube sirva la interfaz de TV.
        // Si YouTube dice "navegador no compatible", cambia este valor.
        private const string TvUserAgent =
            "Mozilla/5.0 (PlayStation; PlayStation 5/2.26) AppleWebKit/605.1.15 " +
            "(KHTML, like Gecko) Version/13.0 Safari/605.1.15";

        private XboxGameBarWidget _widget;
        private DispatcherTimer _hintTimer;

        // Boton del mando -> tecla que YouTube TV entiende (keyCode, nombre de tecla).
        // Edita esta tabla para cambiar los controles.
        private static readonly Dictionary<VirtualKey, KeyValuePair<int, string>> Map =
            new Dictionary<VirtualKey, KeyValuePair<int, string>>
        {
            // Navegacion
            { VirtualKey.GamepadDPadUp,            new KeyValuePair<int,string>(38, "ArrowUp") },
            { VirtualKey.GamepadDPadDown,          new KeyValuePair<int,string>(40, "ArrowDown") },
            { VirtualKey.GamepadDPadLeft,          new KeyValuePair<int,string>(37, "ArrowLeft") },
            { VirtualKey.GamepadDPadRight,         new KeyValuePair<int,string>(39, "ArrowRight") },
            { VirtualKey.GamepadLeftThumbstickUp,    new KeyValuePair<int,string>(38, "ArrowUp") },
            { VirtualKey.GamepadLeftThumbstickDown,  new KeyValuePair<int,string>(40, "ArrowDown") },
            { VirtualKey.GamepadLeftThumbstickLeft,  new KeyValuePair<int,string>(37, "ArrowLeft") },
            { VirtualKey.GamepadLeftThumbstickRight, new KeyValuePair<int,string>(39, "ArrowRight") },

            // A = aceptar, B = atras
            { VirtualKey.GamepadA,                 new KeyValuePair<int,string>(13, "Enter") },
            { VirtualKey.GamepadB,                 new KeyValuePair<int,string>(27, "Escape") },

            // X = play/pausa
            { VirtualKey.GamepadX,                 new KeyValuePair<int,string>(179, "MediaPlayPause") },

            // LB / RB = retroceder / adelantar
            { VirtualKey.GamepadLeftShoulder,      new KeyValuePair<int,string>(412, "MediaRewind") },
            { VirtualKey.GamepadRightShoulder,     new KeyValuePair<int,string>(417, "MediaFastForward") },
        };

        public MainPage()
        {
            InitializeComponent();

            // El evento "Accelerator" llega antes que la navegacion de foco de XAML,
            // asi el D-pad no se "roba" para mover el foco por la ventana.
            Window.Current.CoreWindow.Dispatcher.AcceleratorKeyActivated += OnAcceleratorKey;
            Unloaded += (s, e) =>
                Window.Current.CoreWindow.Dispatcher.AcceleratorKeyActivated -= OnAcceleratorKey;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            _widget = e.Parameter as XboxGameBarWidget;
            LoadYouTube();
        }

        private void LoadYouTube()
        {
            var request = new HttpRequestMessage(HttpMethod.Get, new Uri(TvUrl));
            request.Headers.TryAppendWithoutValidation("User-Agent", TvUserAgent);
            Web.NavigateWithHttpRequestMessage(request);
        }

        private void Web_NavigationCompleted(WebView sender, WebViewNavigationCompletedEventArgs args)
        {
            ShowHint("A: elegir   B: atras   X: pausa   LB/RB: -/+   Vista: recargar", 6);
        }

        private void Web_NavigationFailed(object sender, WebViewNavigationFailedEventArgs e)
        {
            ShowHint("No se pudo cargar YouTube (" + e.WebErrorStatus + "). Pulsa Vista para reintentar.", 0);
        }

        private async void OnAcceleratorKey(CoreDispatcher sender, AcceleratorKeyEventArgs args)
        {
            if (args.EventType != CoreAcceleratorKeyEventType.KeyDown)
            {
                return;
            }

            VirtualKey key = args.VirtualKey;

            // Vista (View) = recargar. Menu = volver al inicio de YouTube.
            if (key == VirtualKey.GamepadView)
            {
                args.Handled = true;
                LoadYouTube();
                return;
            }
            if (key == VirtualKey.GamepadMenu)
            {
                args.Handled = true;
                LoadYouTube();
                return;
            }

            KeyValuePair<int, string> mapped;
            if (Map.TryGetValue(key, out mapped))
            {
                args.Handled = true;
                await SendKeyAsync(mapped.Key, mapped.Value);
            }
        }

        // Inyecta un evento de teclado en la pagina de YouTube.
        private async Task SendKeyAsync(int keyCode, string keyName)
        {
            string js =
                "(function(){" +
                "var k=" + keyCode + ",n='" + keyName + "';" +
                "var t=document.activeElement||document.body;" +
                "['keydown','keyup'].forEach(function(type){" +
                "var e=new KeyboardEvent(type,{key:n,code:n,bubbles:true,cancelable:true});" +
                "try{Object.defineProperty(e,'keyCode',{get:function(){return k;}});" +
                "Object.defineProperty(e,'which',{get:function(){return k;}});}catch(x){}" +
                "t.dispatchEvent(e);});" +
                "})();";

            try
            {
                await Web.InvokeScriptAsync("eval", new[] { js });
            }
            catch (Exception)
            {
                // La pagina aun no esta lista; se ignora la pulsacion.
            }
        }

        private void ShowHint(string text, int seconds)
        {
            HintText.Text = text;
            Hint.Visibility = Visibility.Visible;

            if (_hintTimer != null)
            {
                _hintTimer.Stop();
            }
            if (seconds > 0)
            {
                _hintTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(seconds) };
                _hintTimer.Tick += (s, e) =>
                {
                    Hint.Visibility = Visibility.Collapsed;
                    _hintTimer.Stop();
                };
                _hintTimer.Start();
            }
        }
    }
}
