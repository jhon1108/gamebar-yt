# YouTube para Xbox Game Bar (con mando)

Widget de Xbox Game Bar que abre YouTube en modo TV (`youtube.com/tv`) y lo controla con el mando.

## Requisitos
- Windows 10 (2004+) o Windows 11
- Visual Studio 2022 con la carga de trabajo "Desarrollo de la Plataforma universal de Windows"
- Modo desarrollador de Windows activado (Configuracion > Para desarrolladores)

## Compilar y probar
1. Abre `YouTubeGameBar.sln` en Visual Studio.
2. Doble clic en `Package.appmanifest` > pestana **Empaquetado** > **Elegir certificado...** > **Crear...** (acepta los valores por defecto).
3. Si NuGet se queja de una version, actualiza `Microsoft.Gaming.XboxGameBar` y `Microsoft.NETCore.UniversalWindowsPlatform` desde "Administrar paquetes NuGet".
4. Selecciona **Debug | x64** y pulsa F5. Se instala la app.
5. Pulsa **Win + G**, abre el menu de widgets (icono de widgets) y busca **YouTube**. Ponle la estrella para tenerlo siempre a mano.

## Controles del mando
| Boton | Accion |
|---|---|
| D-pad / Stick izquierdo | Moverse por la interfaz |
| A | Aceptar / reproducir |
| B | Atras |
| X | Play / pausa |
| LB / RB | Retroceder / adelantar |
| Vista (View) o Menu | Recargar YouTube |

Para cambiar los botones edita la tabla `Map` en `MainPage.xaml.cs`.

## Notas
- El mando controla el widget solo cuando Game Bar esta abierto y el widget tiene el foco. Si lo fijas (pin) y cierras Game Bar, el mando vuelve al juego.
- Si YouTube muestra "navegador no compatible", cambia `TvUserAgent` en `MainPage.xaml.cs`.
- Para iniciar sesion usa la opcion de vincular con el telefono de YouTube TV; no esta probado.
